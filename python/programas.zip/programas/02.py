from microbit import *

display.show(Image.SNAKE)
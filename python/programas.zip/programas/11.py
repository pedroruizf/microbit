from microbit import *

for i in range (5):
	display.show(Image.HEART)
	sleep (500)
	display.show(Image.HEART_SMALL)
	sleep (500)
display.clear()
from microbit import *

sleep(12000)
display.scroll(str(button_a.get_presses()))
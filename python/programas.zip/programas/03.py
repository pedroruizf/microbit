from microbit import *

hat = Image("09990:"
	"59995:"
	"00000:"
	"00000:"
	"00000")

display.show(hat)
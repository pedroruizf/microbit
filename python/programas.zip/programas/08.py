from microbit import *

while running_time() < 9000:
	display.show(Image.CLOCK12)

display.show(Image.CLOCK9)
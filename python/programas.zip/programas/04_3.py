from microbit import *
imagenes=[Image.HEART,Image.HEART_SMALL]

while True:
	display.show (imagenes,sleep(500))
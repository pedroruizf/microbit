from microbit import *

display.scroll(”Hola Mundo”)
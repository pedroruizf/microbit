from microbit import *

for y in range (5):
	for x in range (5):
		display.set_pixel(x,y,9)
		sleep (50)
		display.set_pixel (x,y,0)
		sleep (50)

display.clear()